from sklearn.cluster import KMeans


class KMeansModel:

    def __init__(self, random_state=42):
        self.random_state = random_state
        self.model = None

    def compute_inertia_values(self, data, k_range):
        """
        Elbow method implementation.
        """
        inertia_values = []

        start, end = k_range

        for k in range(start, end + 1):
            model = KMeans(
                n_clusters=k,
                random_state=self.random_state,
                n_init=10
            )
            model.fit(data)
            inertia_values.append(model.inertia_)

        return inertia_values

    def train(self, data, k):
        """
        Training final clustering model.
        """
        self.model = KMeans(
            n_clusters=k,
            random_state=self.random_state,
            n_init=10
        )

        labels = self.model.fit_predict(data)

        return labels

    def get_centers(self):
        return self.model.cluster_centers_